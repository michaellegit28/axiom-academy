/**
 * Axiom Academy — Flashcard Engine with SM-2 Spaced Repetition
 */

(function() {
  'use strict';

  class FlashcardEngine {
    constructor() {
      this.config = window.FLASH_CONFIG || {};
      this.cards = [];
      this.currentIndex = 0;
      this.queue = []; // cards to review now
      this.known = 0;
      this.learning = 0;
      this.newCards = 0;

      this.container = document.getElementById('flash-card-container');
      this.cardInner = document.getElementById('flash-card-inner');
      this.frontContent = document.getElementById('front-content');
      this.backContent = document.getElementById('back-content');
      this.counter = document.getElementById('flash-counter');
      this.progressFill = document.getElementById('flash-progress-fill');
      this.statsEl = document.getElementById('flash-stats');
      this.srButtons = document.getElementById('sr-buttons');
      this.completeScreen = document.getElementById('deck-complete');

      this.flipped = false;

      this.init();
    }

    async init() {
      await this.loadCards();
      this.buildQueue();
      this.renderCard();
      this.setupEvents();
    }

    async loadCards() {
      try {
        const dataEl = document.getElementById('flash-data');
        if (dataEl) {
          this.cards = JSON.parse(dataEl.textContent);
        } else if (this.config.dataUrl) {
          const resp = await fetch(this.config.dataUrl);
          const data = await resp.json();
          this.cards = data.cards || [];
        }

        if (!this.cards.length) {
          this.cards = this.getSampleCards();
        }
      } catch (e) {
        console.warn('[Flash] Failed to load:', e);
        this.cards = this.getSampleCards();
      }

      // Load SR state from localStorage
      const srState = JSON.parse(localStorage.getItem('axiom_flash_sr') || '{}');
      this.cards.forEach(card => {
        const state = srState[card.id];
        if (state) {
          card.interval = state.interval || 0;
          card.repetitions = state.repetitions || 0;
          card.efactor = state.efactor || 2.5;
          card.due = state.due || Date.now();
        } else {
          card.interval = 0;
          card.repetitions = 0;
          card.efactor = 2.5;
          card.due = Date.now();
        }
      });
    }

    getSampleCards() {
      return [
        {
          id: 'fc-kin-001',
          front: 'What is the kinematic equation for displacement under constant acceleration?',
          back: '$$s = ut + \\frac{1}{2}at^2$$<br><br>Where:<br>• s = displacement<br>• u = initial velocity<br>• a = acceleration<br>• t = time',
          topic: 'kinematics',
          difficulty: 'easy'
        },
        {
          id: 'fc-kin-002',
          front: 'State Newton\'s Second Law of Motion in both words and equation form.',
          back: '<strong>Words:</strong> The rate of change of momentum is proportional to the applied force.<br><br><strong>Equation:</strong> $$\\mathbf{F} = m\\mathbf{a}$$<br><br>Or more generally: $$\\mathbf{F} = \\frac{d\\mathbf{p}}{dt}$$',
          topic: 'dynamics',
          difficulty: 'easy'
        },
        {
          id: 'fc-kin-003',
          front: 'Derive the relationship between torque and angular acceleration for a rigid body.',
          back: 'Starting with $$\\tau = r \\times F$$ for a single particle...<br><br>For a rigid body: $$\\tau = I\\alpha$$<br><br>Where I is the moment of inertia and α is angular acceleration.',
          topic: 'rotational_motion',
          difficulty: 'hard'
        },
        {
          id: 'fc-kin-004',
          front: 'What is the difference between scalar and vector quantities? Give two examples of each.',
          back: '<strong>Scalar:</strong> Has magnitude only. Examples: mass, speed, temperature, energy.<br><br><strong>Vector:</strong> Has magnitude and direction. Examples: velocity, force, displacement, acceleration.',
          topic: 'measurements',
          difficulty: 'easy'
        },
        {
          id: 'fc-kin-005',
          front: 'Explain why the period of a simple pendulum is independent of its mass.',
          back: 'From dimensional analysis: $$T = k\\sqrt{\\frac{L}{g}}$$<br><br>Mass M has dimension [M]. For dimensional consistency, the exponent of M must be zero. Therefore mass does not appear in the final expression.',
          topic: 'mechanics',
          difficulty: 'medium'
        }
      ];
    }

    buildQueue() {
      const now = Date.now();
      this.queue = this.cards.filter(c => c.due <= now);
      this.newCards = this.queue.filter(c => c.repetitions === 0).length;
      this.learning = this.queue.filter(c => c.repetitions > 0 && c.repetitions < 3).length;
      this.known = this.cards.filter(c => c.repetitions >= 3).length;

      // Sort: learning cards first, then new
      this.queue.sort((a, b) => {
        if (a.repetitions > 0 && b.repetitions === 0) return -1;
        if (a.repetitions === 0 && b.repetitions > 0) return 1;
        return a.due - b.due;
      });

      this.updateStats();
    }

    renderCard() {
      if (this.currentIndex >= this.queue.length) {
        this.showComplete();
        return;
      }

      const card = this.queue[this.currentIndex];
      this.flipped = false;
      this.cardInner.classList.remove('flipped');

      this.frontContent.innerHTML = this.renderMath(card.front);
      this.backContent.innerHTML = this.renderMath(card.back);

      this.counter.textContent = `${this.currentIndex + 1} / ${this.queue.length}`;

      const pct = Math.round((this.currentIndex / this.queue.length) * 100);
      this.progressFill.style.width = pct + '%';

      // Show/hide SR buttons
      this.srButtons.style.display = 'flex';

      // Re-render MathJax
      if (window.MathJax) {
        window.MathJax.typesetPromise?.([this.frontContent, this.backContent]);
      }
    }

    renderMath(text) {
      return text;
    }

    flipCard() {
      this.flipped = !this.flipped;
      this.cardInner.classList.toggle('flipped', this.flipped);
    }

    rateCard(rating) {
      const card = this.queue[this.currentIndex];

      // SM-2 Algorithm
      if (rating >= 3) {
        if (card.repetitions === 0) card.interval = 1;
        else if (card.repetitions === 1) card.interval = 6;
        else card.interval = Math.round(card.interval * card.efactor);

        card.repetitions++;
      } else {
        card.repetitions = 0;
        card.interval = 1;
      }

      // Update ease factor
      card.efactor = card.efactor + (0.1 - (5 - rating) * (0.08 + (5 - rating) * 0.02));
      if (card.efactor < 1.3) card.efactor = 1.3;

      // Set next due date
      const days = card.interval;
      card.due = Date.now() + (days * 24 * 60 * 60 * 1000);

      // Save SR state
      this.saveSRState(card);

      // Move to next
      this.currentIndex++;
      this.renderCard();
    }

    saveSRState(card) {
      const srState = JSON.parse(localStorage.getItem('axiom_flash_sr') || '{}');
      srState[card.id] = {
        interval: card.interval,
        repetitions: card.repetitions,
        efactor: card.efactor,
        due: card.due
      };
      localStorage.setItem('axiom_flash_sr', JSON.stringify(srState));

      // Sync to Firestore
      if (window.AxiomApp?.user && window.AxiomApp.db) {
        window.AxiomApp.db.collection('users')
          .doc(window.AxiomApp.user.uid)
          .collection('flashcards')
          .doc(card.id)
          .set(srState[card.id]);
      }
    }

    updateStats() {
      if (this.statsEl) {
        this.statsEl.innerHTML = `
          <span style="color:var(--accent-success)">Known: ${this.known}</span>
          <span style="color:var(--accent-warning)">Learning: ${this.learning}</span>
          <span style="color:var(--accent-waec)">New: ${this.newCards}</span>
        `;
      }
    }

    showComplete() {
      this.container.style.display = 'none';
      this.srButtons.style.display = 'none';
      document.querySelector('.flash-nav').style.display = 'none';
      this.completeScreen.style.display = 'block';

      const stats = document.getElementById('deck-complete-stats');
      if (stats) {
        stats.textContent = `You reviewed ${this.queue.length} cards. ${this.known} are now in long-term memory.`;
      }
    }

    restartDeck() {
      this.currentIndex = 0;
      this.buildQueue();
      this.container.style.display = 'block';
      this.srButtons.style.display = 'flex';
      document.querySelector('.flash-nav').style.display = 'flex';
      this.completeScreen.style.display = 'none';
      this.renderCard();
    }

    setupEvents() {
      // Flip on click/space
      this.cardInner?.addEventListener('click', () => this.flipCard());
      document.addEventListener('keydown', (e) => {
        if (e.code === 'Space') {
          e.preventDefault();
          this.flipCard();
        }
      });

      // SR buttons
      this.srButtons?.querySelectorAll('.sr-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const rating = parseInt(btn.dataset.rating);
          this.rateCard(rating);
        });
      });

      // Keyboard shortcuts for ratings
      document.addEventListener('keydown', (e) => {
        if (!this.flipped) return;
        const map = { '1': 1, '2': 2, '3': 3, '4': 4 };
        if (map[e.key]) {
          this.rateCard(map[e.key]);
        }
      });

      // Nav buttons
      document.getElementById('btn-prev-card')?.addEventListener('click', () => {
        if (this.currentIndex > 0) {
          this.currentIndex--;
          this.renderCard();
        }
      });

      document.getElementById('btn-next-card')?.addEventListener('click', () => {
        if (this.currentIndex < this.queue.length - 1) {
          this.currentIndex++;
          this.renderCard();
        }
      });
    }
  }

  if (document.querySelector('.flash-wrapper')) {
    window.flashcards = new FlashcardEngine();
  }
})();
