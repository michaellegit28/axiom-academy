/**
 * Axiom Academy — App Shell Controller
 * Handles SPA-like transitions, auth state UI, active tab highlighting.
 */

import { axiomAuth } from "./auth.js";

// Active tab highlighting
function setActiveTab() {
  const path = window.location.pathname;
  document.querySelectorAll('.nav-item').forEach(item => {
    const href = item.getAttribute('href') || '';
    const tab = item.dataset.tab;

    // Normalize baseurl
    const base = document.querySelector('base')?.href || '';
    const cleanPath = path.replace(base, '/');

    if (tab === 'read' && cleanPath.startsWith('/read/')) item.classList.add('active');
    else if (tab === 'quiz' && cleanPath.startsWith('/quiz/')) item.classList.add('active');
    else if (tab === 'flash' && cleanPath.startsWith('/flash/')) item.classList.add('active');
    else if (tab === 'profile' && cleanPath.startsWith('/profile/')) item.classList.add('active');
    else if (cleanPath === '/' || cleanPath === '/index.html') {
      // Landing page — no tab active
    }
    else if (item.classList.contains('active')) {
      item.classList.remove('active');
    }
  });
}

// Auth button state
function updateAuthUI(user, isAnonymous) {
  const btn = document.getElementById('auth-btn');
  if (!btn) return;

  if (user && !isAnonymous) {
    btn.textContent = user.displayName || 'Profile';
    btn.onclick = () => window.location.href = document.querySelector('base')?.href + 'profile/' || '/profile/';
  } else {
    btn.textContent = 'Sign In';
    btn.onclick = () => {
      // Simple prompt for email — replace with modal later
      const email = prompt('Enter email to create account:');
      if (email) {
        const password = prompt('Create password:');
        if (password) {
          axiomAuth.upgradeToEmail(email, password, email.split('@')[0])
            .then(() => alert('Account created!'))
            .catch(err => alert(err.message));
        }
      }
    };
  }
}

// Intercept nav clicks for SPA feel (optional enhancement)
document.addEventListener('click', (e) => {
  const link = e.target.closest('a[data-tab]');
  if (!link) return;

  const href = link.getAttribute('href');
  if (!href || href.startsWith('http')) return;

  // Let browser handle if modifier keys pressed
  if (e.metaKey || e.ctrlKey || e.shiftKey) return;

  // For now, let full page loads happen on GitHub Pages
  // (Turbo-style interception can be added in Phase 6)
});

// Init
setActiveTab();
axiomAuth.onAuthChange(updateAuthUI);

// Re-highlight on popstate
window.addEventListener('popstate', setActiveTab);
