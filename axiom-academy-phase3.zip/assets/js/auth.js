/**
 * Axiom Academy — Auth Module
 * Handles anonymous auth, account upgrades, and user doc initialization.
 * Works on GitHub Pages with Firebase CDN ES modules.
 */

import {
  getAuth,
  signInAnonymously,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
  linkWithCredential,
  EmailAuthProvider,
  onAuthStateChanged,
  updateProfile
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

class AxiomAuth {
  constructor() {
    this.auth = getAuth(window.firebaseApp);
    this.db = getFirestore(window.firebaseApp);
    this.user = null;
    this.isAnonymous = true;
    this.listeners = [];
    this._ready = false;
    this._readyCallbacks = [];

    onAuthStateChanged(this.auth, async (user) => {
      if (user) {
        this.user = user;
        this.isAnonymous = user.isAnonymous;
        await this._ensureUserDoc(user);
        this._ready = true;
        this._notifyReady();
        this._notifyListeners();
      } else {
        await signInAnonymously(this.auth);
      }
    });
  }

  whenReady() {
    return new Promise((resolve) => {
      if (this._ready && this.user) resolve(this.user);
      else this._readyCallbacks.push(resolve);
    });
  }

  _notifyReady() {
    this._readyCallbacks.forEach(cb => cb(this.user));
    this._readyCallbacks = [];
  }

  async _ensureUserDoc(user) {
    const ref = doc(this.db, "users", user.uid);
    const snap = await getDoc(ref);

    if (!snap.exists()) {
      await setDoc(ref, {
        profile: {
          displayName: user.displayName || "Learner",
          email: user.email || null,
          avatar: user.photoURL || null,
          createdAt: serverTimestamp(),
          lastActive: serverTimestamp()
        },
        progress: {},
        quiz_scores: {},
        weak_topics: {},
        study_track: {
          currentGoal: null,
          dailyTargetMinutes: 60,
          streakDays: 0,
          lastStudyDate: null
        },
        flashcard_progress: {}
      });
    } else {
      await setDoc(ref, { "profile.lastActive": serverTimestamp() }, { merge: true });
    }
  }

  onAuthChange(callback) {
    this.listeners.push(callback);
    if (this.user) callback(this.user, this.isAnonymous);
    return () => {
      this.listeners = this.listeners.filter(cb => cb !== callback);
    };
  }

  _notifyListeners() {
    this.listeners.forEach(cb => cb(this.user, this.isAnonymous));
  }

  // Upgrade anonymous account to email/password
  async upgradeToEmail(email, password, displayName) {
    if (!this.isAnonymous) throw new Error("Already authenticated");
    const credential = EmailAuthProvider.credential(email, password);
    const result = await linkWithCredential(this.auth.currentUser, credential);
    if (displayName) {
      await updateProfile(result.user, { displayName });
    }
    this.user = result.user;
    this.isAnonymous = false;
    this._notifyListeners();
    return result.user;
  }

  async signInWithGoogle() {
    const provider = new GoogleAuthProvider();
    if (this.isAnonymous && this.auth.currentUser) {
      const result = await linkWithCredential(this.auth.currentUser, provider);
      this.user = result.user;
      this.isAnonymous = false;
      this._notifyListeners();
      return result.user;
    }
    const result = await signInWithPopup(this.auth, provider);
    this.user = result.user;
    this.isAnonymous = false;
    this._notifyListeners();
    return result.user;
  }

  async signInEmail(email, password) {
    const result = await signInWithEmailAndPassword(this.auth, email, password);
    this.user = result.user;
    this.isAnonymous = false;
    this._notifyListeners();
    return result.user;
  }

  get uid() {
    return this.user ? this.user.uid : null;
  }
}

export const axiomAuth = new AxiomAuth();
export default axiomAuth;
