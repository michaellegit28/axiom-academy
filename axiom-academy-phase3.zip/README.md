# Axiom Academy — Phase 3: Flashcards

This package adds the **Flashcard Engine** with SM-2 spaced repetition to your Jekyll site.

## What's Included

| File | Purpose |
|------|---------|
| `firestore.rules` | Security rules — deploy immediately |
| `_config.yml` | Jekyll collection config (merge into yours) |
| `_layouts/app-shell.html` | Persistent nav + Firebase init |
| `_layouts/flash.html` | Flashcard deck page layout |
| `_includes/firebase-init.html` | Firebase SDK bootstrap |
| `_includes/bottom-nav.html` | Mobile bottom tab bar |
| `assets/js/auth.js` | Anonymous + email + Google auth |
| `assets/js/flashcards.js` | SM-2 engine + offline sync |
| `assets/js/app-shell.js` | Active tab + auth UI |
| `assets/css/flashcards.css` | All styles + design tokens |
| `flash/index.html` | Deck browser |
| `flash/physics/kinematics.md` | Sample deck |
| `flash/physics/dynamics.md` | Sample deck |
| `_data/flashcards/physics/kinematics.yml` | Data source (optional) |

## Setup Instructions

### 1. Merge `_config.yml`

Add the `flashcards` collection from the provided `_config.yml` into your existing `_config.yml`. Do NOT overwrite your entire file.

```yaml
collections:
  flashcards:
    output: true
    permalink: /flash/:path/
```

### 2. Deploy Firestore Rules

```bash
firebase deploy --only firestore:rules
```

Or paste `firestore.rules` into the Firebase Console → Firestore Database → Rules.

### 3. Copy Files

Copy all folders (`_layouts`, `_includes`, `_data`, `assets`, `flash`) into your Jekyll repo root.

### 4. Update Existing Layouts

Change your existing chapter layouts to use `layout: app-shell` (or include the bottom nav + Firebase init manually).

### 5. Build & Test

```bash
bundle exec jekyll serve
```

Visit:
- `http://localhost:4000/flash/` — Deck browser
- `http://localhost:4000/flash/physics/kinematics/` — Study deck

## How It Works

### Offline-First
- Card progress is stored in **IndexedDB** (primary) and **localStorage** (fallback)
- No internet required to review cards

### Cloud Sync
- When a user upgrades from anonymous → authenticated, progress auto-syncs to Firestore
- Cloud data is merged intelligently (keeps the most recent review timestamp)

### SM-2 Algorithm
- **Again (1)**: Card goes back to learning, interval resets
- **Hard (2)**: Small interval increase, easiness factor drops slightly
- **Good (3)**: Standard SM-2 interval progression
- **Easy (4)**: Larger interval, easiness factor increases

### Keyboard Shortcuts
| Key | Action |
|-----|--------|
| `Space` / `Enter` | Flip card |
| `1` | Again |
| `2` | Hard |
| `3` | Good |
| `4` | Easy |

## Adding New Decks

Create a new file: `flash/physics/[topic].md`

```yaml
---
layout: flash
title: "Thermodynamics"
deck_id: physics_thermodynamics
subject: physics
topic: thermodynamics
cards:
  - id: fc-thermo-001
    front: "What is the first law of thermodynamics?"
    back: "$$\Delta U = Q - W$$"
    difficulty: easy
---
```

Then add it to `flash/index.html` in the deck grid.

## Next Steps (Phase 4)

1. Build `/profile/` page with progress dashboard
2. Add score analysis + weak topic detection
3. Implement study track scheduler

## Troubleshooting

**Cards not loading?** Check browser console for CORS errors. Ensure Firebase Auth domain whitelist includes your GitHub Pages domain.

**Math not rendering?** MathJax loads asynchronously. The flashcard UI calls `typesetPromise` after each card change.

**Bottom nav not showing?** It's fixed-position and requires `viewport-fit=cover` in the meta tag (included in `app-shell.html`).
